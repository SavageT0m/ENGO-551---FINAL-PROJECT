import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const Schema = mongoose.Schema;
const userSchema = new Schema({
  email: {
    type: String,
    required: true,
    unique: true,
  },
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  // profilePicture: {
  //   url: String,
  //   filename: String,
  // },
  password: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  productNumber: {
    type: String,
    required: true,
  },
});

// finds a user and checks if the password is correct
userSchema.statics.findAndValidate = async function (email, password) {
  const user = await this.findOne({ email });
  if (!user) return false;
  const isValid = await bcrypt.compare(password, user.password);
  return isValid ? user : false;
};

// before saving password to the database, hash it
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

export default mongoose.model('User', userSchema);
