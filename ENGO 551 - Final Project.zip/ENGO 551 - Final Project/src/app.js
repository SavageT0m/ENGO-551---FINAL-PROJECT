import dotenv from 'dotenv';

if (process.env.NODE_ENV !== 'production') {
  dotenv.config();
}

import { URL, fileURLToPath } from 'url';
// import methodOverride from 'method-override';
import mongoose from 'mongoose';
import express from 'express';
import session from 'express-session';
import User from '../models/user.js';

// connecting mongoose to database
mongoose.connect(process.env.URI).catch(error => console.log(error));
// file path to public folder
const __public = fileURLToPath(new URL('../public', import.meta.url));

const app = express();

// app.use(methodOverride('_method'));
app.use(express.static(__public));
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    resave: false,
    saveUninitialized: false,
    secret: 'thiscouldbebetter',
  })
);

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});

// Use this middleware function to require being logged in
const requireLogin = (req, res, next) => {
  if (!req.session.user) return res.redirect('/login');
  next();
};

app.get('/', async (req, res) => {
  res.render('WelcomePage.ejs');
});

app.get('/main', requireLogin, async (req, res) => {
  res.render('Main.ejs');
});

app.get('/product', requireLogin, async (req, res) => {
  res.render('OurProduct.ejs');
});

app.get('/register', (req, res) => {
  res.render('SignUp.ejs');
});

app.get('/login', (req, res) => {
  // if (Object.keys(req.query).length !== 0) {
  //   res.send(res.locals.user);
  // } else
  res.render('LogIn.ejs');
});

app.post('/register', async (req, res) => {
  const { email, firstName, lastName, password, productNumber, address } =
    req.body;
  console.log(`${firstName} ${lastName}`);
  const user = new User({
    email,
    firstName,
    lastName,
    password,
    productNumber,
    address,
  });
  await user.save();
  req.session.user = user;
  res.redirect('/main');
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findAndValidate(email, password);
  if (user) {
    req.session.user = user;
    res.redirect('/main');
  } else {
    res.send('Incorrect email or password');
  }
});

app.post('/logout', (req, res) => {
  req.session.user = null;
  res.redirect('/');
});

app.listen(process.env.PORT, () => {
  console.log('Serving on port 3000');
});
